# Simple NodeJS REST API Scaffolding
+ Bruno collection
+ Nodemon

#### Routes:
- /
- /items
- /items/search
- /users/login