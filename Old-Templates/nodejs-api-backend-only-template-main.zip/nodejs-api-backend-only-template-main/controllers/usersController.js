const getLoginPage = (req, res) => {
  res.send(`/USERS/LOGIN PAGE`);
};

module.exports = { getLoginPage };
