const getIndexLandingPage = (req, res) => {
  res.send(`/ PAGE`);
};

module.exports = { getIndexLandingPage };